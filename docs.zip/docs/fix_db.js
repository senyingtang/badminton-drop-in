const { Client } = require('pg');
const fs = require('fs');

function getEnv() {
  const envText = fs.readFileSync('../.env', 'utf8')
  const env = {}
  for (const line of envText.split('\n')) {
    if (line.trim() && !line.startsWith('#')) {
      const parts = line.split('=')
      if (parts.length >= 2) {
        env[parts[0].trim()] = parts.slice(1).join('=').trim()
      }
    }
  }
  return env
}

async function fix() {
  const env = getEnv();
  const dbUrl = env.DATABASE_URL;
  if (!dbUrl) throw new Error("No DB URL");

  const client = new Client({ connectionString: dbUrl });
  await client.connect();

  try {
    const email = 'senyingtang2025@gmail.com';
    
    // 1. Get user id
    const res = await client.query("SELECT id FROM app_user_profiles p JOIN auth.users u ON p.id = u.id WHERE u.email = $1", [email]);
    if (res.rows.length === 0) {
      console.log("User not found!");
      return;
    }
    const userId = res.rows[0].id;
    console.log("Found user ID:", userId);

    // 2. Make platform_admin
    await client.query("UPDATE app_user_profiles SET primary_role = 'platform_admin' WHERE id = $1", [userId]);
    console.log("Set to platform_admin.");

    // 3. Fix billing account if missing
    const billRes = await client.query("SELECT id FROM kb_billing_accounts WHERE host_id = $1", [userId]);
    if (billRes.rows.length === 0) {
      await client.query(`
        INSERT INTO kb_billing_accounts (host_id, plan_id, status)
        VALUES ($1, 'free', 'active')
      `, [userId]);
      console.log("Created missing billing account.");
    } else {
      console.log("Billing account already exists.");
    }

    // 4. Ensure wallet exists
    const walletRes = await client.query("SELECT balance FROM kb_wallets WHERE user_id = $1", [userId]);
    if (walletRes.rows.length === 0) {
        await client.query("INSERT INTO kb_wallets (user_id, balance) VALUES ($1, 0)", [userId]);
        console.log("Created missing wallet.");
    }

  } catch (e) {
    console.error(e);
  } finally {
    await client.end();
  }
}

fix();
