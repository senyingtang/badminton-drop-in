const { createClient } = require('@supabase/supabase-js');
const fs = require('fs');

function getEnv() {
  const envText = fs.readFileSync('../.env', 'utf8')
  const env = {}
  for (const line of envText.split('\n')) {
    if (line.trim() && !line.startsWith('#')) {
      const parts = line.split('=')
      if (parts.length >= 2) {
        env[parts[0].trim()] = parts.slice(1).join('=').trim()
      }
    }
  }
  return env
}

async function fixAdmin() {
  const env = getEnv();
  const supabase = createClient(env.SUPABASE_URL, env.SUPABASE_SERVICE_ROLE_KEY);

  const email = 'senyingtang2025@gmail.com';
  
  // Get user from auth
  const { data: usersData, error: usersErr } = await supabase.auth.admin.listUsers();
  if (usersErr) {
      console.error(usersErr);
      return;
  }
  const user = usersData.users.find(u => u.email === email);
  if (!user) {
      console.log('User not found in Auth!');
      return;
  }

  // Update app_user_profiles
  const { error: updateErr } = await supabase
    .from('app_user_profiles')
    .update({ primary_role: 'platform_admin' })
    .eq('id', user.id);

  if (updateErr) {
    console.error('Failed to update app_user_profiles:', updateErr);
  } else {
    console.log(`Successfully elevated ${email} to platform_admin!`);
  }

  // Ensure they have a billing account so they don't get the quota error
  const { data: billData } = await supabase.from('kb_billing_accounts').select('id').eq('host_id', user.id);
  if (!billData || billData.length === 0) {
      await supabase.from('kb_billing_accounts').insert({ host_id: user.id, plan_id: 'free', status: 'active' });
      console.log("Created missing billing account.");
  }
  
  // Ensure wallet exists
  const { data: walletData } = await supabase.from('kb_wallets').select('id').eq('user_id', user.id);
  if (!walletData || walletData.length === 0) {
      await supabase.from('kb_wallets').insert({ user_id: user.id, balance: 0 });
      console.log("Created missing wallet.");
  }
}

fixAdmin();
